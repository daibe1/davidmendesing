(function() {
	
	function clickVid(){

		location.href = "Android/log.html";
	}

	$(".img _lt3 _4s0y").click(clickVid);

});